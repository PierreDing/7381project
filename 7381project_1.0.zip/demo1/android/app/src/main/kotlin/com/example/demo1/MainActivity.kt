package com.example.demo1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
