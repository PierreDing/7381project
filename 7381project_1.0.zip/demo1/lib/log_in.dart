import 'package:demo1/pages/Tabs.dart';
import 'package:flutter/material.dart';
import '../main.dart';

class LogInPage extends StatelessWidget {
  const LogInPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          Opacity(
            opacity: 0.5,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage("assets/img/homepage.jpg") )
              ),
            ),
          ),
          SingleChildScrollView(
            child: Form(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("holotype",
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: "Georgia",
                        fontSize: 80,
                        fontWeight: FontWeight.bold,
                      ),),
                    const SizedBox(height: 75,),
                    Container(
                      width: 300,
                      height: 200,
                      child: ListView(
                        children: [
                          TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            autofocus: false,
                            decoration: InputDecoration(
                                icon: const Icon(Icons.email),
                                hintText: "Email address",
                                hintStyle: const TextStyle(
                                    fontSize: 20,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                          const SizedBox(height: 20,),
                          TextFormField(
                              autofocus: false,
                              obscureText: true,
                              decoration: InputDecoration(
                                hintText: "Password",
                                hintStyle: const TextStyle(
                                    fontSize: 20,
                                    color: Colors.black),
                                icon: const Icon(Icons.lock),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(32.0),
                                ),
                              )
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 75,),
                    Container(
                        width: 300,
                        height: 60,
                        color: Colors.orange,
                        child: TextButton(
                          onPressed: (){
                            Navigator.of(context).push(
                                MaterialPageRoute(builder: (BuildContext context) {
                                  return const Tabs();
                                })
                            );
                          },
                          child: const Text("LOG IN",style: TextStyle(
                              fontSize: 30,
                              color: Colors.white),),
                        )
                    ),
                    const SizedBox(height: 30,),
                    FloatingActionButton(onPressed: (){
                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (BuildContext context) {
                            return const MyApp();
                          })
                      );
                    },
                      child: const Icon(Icons.home),)
                  ],
                ),
            )
          )
        ],
      ),
    );
  }


}