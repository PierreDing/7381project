import 'package:demo1/pages/tabs/Details.dart';
import 'package:demo1/pages/tabs/User_Profile.dart';
import 'package:flutter/material.dart';
import 'package:demo1/pages/message_page.dart';
import 'package:demo1/pages/setting_page.dart';
import 'package:demo1/pages/Tabs.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [Top(), Text1(), Text2(), Block1(), Block2(), Block3()],
    );
  }
}

// Message, Search and UserProfile
class Top extends StatelessWidget {
  const Top({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(children: [
        Container(
          // Message
          height: 50,
          margin: EdgeInsets.fromLTRB(20, 10, 220, 10),
          child: IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) {
                return MessagePage();
              }));
            },
            icon: Icon(
              Icons.mail_outline,
              color: Color.fromARGB(255, 44, 94, 70),
            ),
            iconSize: 30,
          ),
        ),
        Container(
          // Search
          height: 30,
          margin: EdgeInsets.fromLTRB(0, 10, 10, 10),
          child: Icon(
            Icons.search,
            color: Color.fromARGB(255, 44, 94, 70),
            size: 30,
          ),
        ),
        Container(
          // User Image
          child: IconButton(
            icon: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/img/img.png"),
                      fit: BoxFit.cover,
                    ),
                    shape: BoxShape.circle)),
            onPressed: () {
              // TODO: BUG
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) {
                  return Tabs();
                },
              ));
            },
          ),
        )
      ]),
    );
  }
}

// Text1
class Text1 extends StatelessWidget {
  const Text1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(30, 0, 20, 0),
      child: Text(
        "Today",
        style: TextStyle(
            fontFamily: "Fatface",
            color: Color.fromARGB(255, 44, 94, 70),
            fontSize: 30),
      ),
    );
  }
}

// Text2
class Text2 extends StatelessWidget {
  const Text2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(30, 0, 20, 0),
      child: Text(
        "New & Popular Story",
        style: TextStyle(
            fontFamily: "Fatface",
            color: Color.fromARGB(255, 44, 94, 70),
            fontSize: 30),
      ),
    );
  }
}

// Block1
class Block1 extends StatelessWidget {
  const Block1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
      height: 350,
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: Center(
          child: Container(
        // BackGround
        width: 350,
        height: 350,
        decoration: BoxDecoration(
            color: Color.fromRGBO(44, 94, 70, 0.1),
            borderRadius: BorderRadius.all(Radius.circular(20))),
        child: Stack(children: [
          Positioned(
            // Img
            top: 10,
            left: 35,
            child: InkWell(
              onTap: () {
                // TODO: To Details Page
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) {
                    return DetailPage();
                  },
                ));
              },
              child: Ink.image(
                  image: AssetImage('assets/img/Plant10.jpg'),
                  width: 280.0,
                  height: 180.0,
                  fit: BoxFit.cover),
            ),
          ),
          Positioned(
              // Text "New"
              top: 210,
              left: 35,
              child: Text(
                "New",
                style: TextStyle(color: Colors.orange, fontSize: 12),
              )),
          Positioned(
              // Text "BRIEF INFORMATION"
              top: 235,
              left: 35,
              child: Text(
                "BRIEF INFORMATION",
                style: TextStyle(
                    color: Colors.orange, fontSize: 20, fontFamily: "Broadway"),
              )),
          Positioned(
              // Text "Dark green, broad leaves with veins"
              top: 260,
              left: 35,
              child: Text(
                "Dark green, broad leaves with veins",
                style: TextStyle(color: Colors.orange, fontSize: 12),
              )),
          Positioned(
              // Text "Report"
              top: 310,
              left: 35,
              child: Text(
                "Report",
                style: TextStyle(
                    color: Color.fromRGBO(44, 94, 70, 1), fontSize: 12),
              )),
          Positioned(
            // Row with 3 icons
            top: 295,
            left: 180,
            child: Container(
                width: 150,
                height: 40,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Icon(
                      Icons.thumb_up,
                      color: Colors.orange,
                      size: 30,
                    ),
                    Icon(
                      Icons.text_snippet,
                      color: Colors.orange,
                      size: 30,
                    ),
                    Icon(
                      Icons.location_pin,
                      color: Colors.orange,
                      size: 30,
                    )
                  ],
                )),
          ),
          Positioned(
              top: 308,
              left: 203,
              child: Text(
                "5",
                style: TextStyle(color: Colors.white, fontSize: 15),
              ))
        ]),
      )),
    );
  }
}

// Block2
class Block2 extends StatelessWidget {
  const Block2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
      height: 350,
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: Center(
          child: Container(
        // BackGround
        width: 350,
        height: 350,
        decoration: BoxDecoration(
            color: Color.fromRGBO(44, 94, 70, 0.1),
            borderRadius: BorderRadius.all(Radius.circular(20))),
        child: Stack(children: [
          Positioned(
              // Img
              top: 10,
              left: 35,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15), // Image border
                child: SizedBox.fromSize(
                  child: Image.asset("assets/img/Plant3.jpg",
                      width: 280.0, height: 180.0, fit: BoxFit.cover),
                ),
              )),
          Positioned(
              // Text "New"
              top: 210,
              left: 35,
              child: Text(
                "New",
                style: TextStyle(color: Colors.orange, fontSize: 12),
              )),
          Positioned(
              // Text "BRIEF INFORMATION"
              top: 235,
              left: 35,
              child: Text(
                "BRIEF INFORMATION",
                style: TextStyle(
                    color: Colors.orange, fontSize: 20, fontFamily: "Broadway"),
              )),
          Positioned(
              // Text "Dark green, broad leaves with veins"
              top: 260,
              left: 35,
              child: Text(
                "Dark green, broad leaves with veins",
                style: TextStyle(color: Colors.orange, fontSize: 12),
              )),
          Positioned(
              // Text "Report"
              top: 310,
              left: 35,
              child: Text(
                "Report",
                style: TextStyle(
                    color: Color.fromRGBO(44, 94, 70, 1), fontSize: 12),
              )),
          Positioned(
            // Row with 3 icons
            top: 295,
            left: 180,
            child: Container(
                width: 150,
                height: 40,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Icon(
                      Icons.thumb_up,
                      color: Colors.orange,
                      size: 30,
                    ),
                    Icon(
                      Icons.text_snippet,
                      color: Colors.orange,
                      size: 30,
                    ),
                    Icon(
                      Icons.location_pin,
                      color: Colors.orange,
                      size: 30,
                    )
                  ],
                )),
          ),
          Positioned(
              top: 308,
              left: 203,
              child: Text(
                "8",
                style: TextStyle(color: Colors.white, fontSize: 15),
              ))
        ]),
      )),
    );
  }
}

// Block3
class Block3 extends StatelessWidget {
  const Block3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
      height: 350,
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: Center(
          child: Container(
        // BackGround
        width: 350,
        height: 350,
        decoration: BoxDecoration(
            color: Color.fromRGBO(44, 94, 70, 0.1),
            borderRadius: BorderRadius.all(Radius.circular(20))),
        child: Stack(children: [
          Positioned(
              // Img
              top: 10,
              left: 35,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15), // Image border
                child: SizedBox.fromSize(
                  child: Image.asset("assets/img/Plant1.jpg",
                      width: 280.0, height: 180.0, fit: BoxFit.cover),
                ),
              )),
          Positioned(
              // Text "New"
              top: 210,
              left: 35,
              child: Text(
                "New",
                style: TextStyle(color: Colors.orange, fontSize: 12),
              )),
          Positioned(
              // Text "BRIEF INFORMATION"
              top: 235,
              left: 35,
              child: Text(
                "BRIEF INFORMATION",
                style: TextStyle(
                    color: Colors.orange, fontSize: 20, fontFamily: "Broadway"),
              )),
          Positioned(
              // Text "Dark green, broad leaves with veins"
              top: 260,
              left: 35,
              child: Text(
                "Dark green, broad leaves with veins",
                style: TextStyle(color: Colors.orange, fontSize: 12),
              )),
          Positioned(
              // Text "Report"
              top: 310,
              left: 35,
              child: Text(
                "Report",
                style: TextStyle(
                    color: Color.fromRGBO(44, 94, 70, 1), fontSize: 12),
              )),
          Positioned(
            // Row with 3 icons
            top: 295,
            left: 180,
            child: Container(
                width: 150,
                height: 40,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Icon(
                      Icons.thumb_up,
                      color: Colors.orange,
                      size: 30,
                    ),
                    Icon(
                      Icons.text_snippet,
                      color: Colors.orange,
                      size: 30,
                    ),
                    Icon(
                      Icons.location_pin,
                      color: Colors.orange,
                      size: 30,
                    )
                  ],
                )),
          ),
          Positioned(
              top: 308,
              left: 203,
              child: Text(
                "5",
                style: TextStyle(color: Colors.white, fontSize: 15),
              ))
        ]),
      )),
    );
  }
}
