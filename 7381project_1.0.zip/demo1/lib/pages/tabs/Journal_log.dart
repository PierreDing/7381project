import 'package:demo1/pages/Tabs.dart';
import 'package:flutter/material.dart';
import '../../main.dart';

class JournalLog extends StatelessWidget {
  const JournalLog({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
              onPressed: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (BuildContext context){
                    return const JournalLog();
                  })
                );
              },
              icon: const Icon(Icons.refresh)
          ),
          IconButton(
              onPressed: (){
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context){
                      return const MyApp();
                    })
                );
              },
              icon: const Icon(Icons.home)
          )
        ]
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("JOURNAL LOG",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            SingleChildScrollView(
              child: Form(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(

                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: 240,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Brief Information",
                                hintStyle: const TextStyle(
                                    fontSize: 20,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 140,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Location",
                                hintStyle: const TextStyle(
                                    fontSize: 20,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(
                          width: 120,
                          height: 120,
                          child: Container(color: Colors.white54,),
                        ),
                        SizedBox(
                          width: 120,
                          height: 120,
                          child: Container(color: Colors.white54,),
                        ),
                        SizedBox(
                          width: 120,
                          height: 120,
                          child: Container(color: Colors.white54,),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20,),
                    const Text("Notable Features:",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(
                          width: 70,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Feature1",
                                hintStyle: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 70,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Feature2",
                                hintStyle: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 70,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Feature3",
                                hintStyle: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 70,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Feature3",
                                hintStyle: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 70,
                          child: TextFormField(
                            autofocus: false,
                            decoration: InputDecoration(
                                hintText: "Feature3",
                                hintStyle: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.black),
                                contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(32.0)
                                )
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20,),
                    SizedBox(
                      width: double.infinity,
                      height: 200,
                      child: TextFormField(
                        autofocus: false,
                        maxLines: 10,
                        decoration: InputDecoration(
                            hintText: "Description:",
                            hintStyle: const TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                            ),
                            contentPadding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(32.0)
                            )
                        ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                  ],
                ),
              ),
            ),
            Container(
                width: 300,
                height: 60,
                color: Colors.orange,
                child: TextButton(
                  onPressed: (){
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return const Tabs();
                        })
                    );
                  },
                  child: const Text("Share",style: TextStyle(
                      fontSize: 30,
                      color: Colors.white),),
                )
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add_a_photo),
        onPressed: (){},
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endTop,
    );
  }

}

