import 'package:flutter/material.dart';

class SettingPage extends StatelessWidget {
  const SettingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [Top(), Img(), Name(), Expanded(child: List()), Logout()],
      ),
    );
  }
}

class Top extends StatelessWidget {
  const Top({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(10, 30, 10, 0),
      height: 80,
      width: 400,
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: Row(
        children: [
          // SizedBox(
          //   height: 150,
          //   width: 30,
          // ),
          IconButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Icon(
                Icons.arrow_back,
                size: 30,
                color: Color.fromARGB(255, 44, 94, 70),
              )),
          Text(
            "                  Messages",
            style: TextStyle(
                fontFamily: 'Fatface',
                color: Color.fromARGB(255, 44, 94, 70),
                fontSize: 28),
            textAlign: TextAlign.end,
          )
        ],
      ),
    );
  }
}

class Img extends StatelessWidget {
  const Img({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
      height: 80,
      width: 400,
      decoration: BoxDecoration(
          // border: Border.all(color: Colors.red),
          image: DecorationImage(
              image: AssetImage("assets/img/img.png"), fit: BoxFit.contain),
          color: Colors.white,
          shape: BoxShape.circle),
    );
  }
}

class Name extends StatelessWidget {
  const Name({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 0),
      height: 30,
      width: 400,
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: Center(
          child: Text(
        "Agnes Don",
        style: TextStyle(fontSize: 20),
      )),
    );
  }
}

class List extends StatelessWidget {
  const List({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.privacy_tip),
            title: Text('Privacy'),
            trailing: Icon(Icons.keyboard_arrow_right),
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.security),
            title: Text('Security'),
            trailing: Icon(Icons.keyboard_arrow_right),
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.language),
            title: Text('Display and languages'),
            trailing: Icon(Icons.keyboard_arrow_right),
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.help),
            title: Text('Help'),
            trailing: Icon(Icons.keyboard_arrow_right),
          ),
        ],
      ),
    );
  }
}

class Logout extends StatelessWidget {
  const Logout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 50),
      // decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: ElevatedButton(
          onPressed: () {
            // TODO: Log Out
          },
          style: ElevatedButton.styleFrom(
            minimumSize: Size(300, 50),
            primary: Colors.orange,
          ),
          child: Text(
            "LOG OUT",
            style: TextStyle(color: Colors.white, fontSize: 30),
          )),
    );
  }
}
