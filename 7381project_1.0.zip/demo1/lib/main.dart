import 'package:flutter/material.dart';
import '../log_in.dart';
import '../sign_up.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
      ),
      home: const MyHomePage(title: 'New Plants'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int counter = 0;

  void _incrementCounter() {
    setState(() {
      counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          Opacity(
            opacity: 0.9,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage("assets/img/homepage.jpg") )
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("holotype",
                style: TextStyle(
                  color: Colors.black,
                  fontFamily: "Georgia",
                  fontSize: 80,
                  fontWeight: FontWeight.bold,
                ),),
              const SizedBox(height: 60,),
              Container(
                  width: 300,
                  height: 60,
                  color: Colors.orange,
                  child: TextButton(
                    onPressed: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return const LogInPage();
                        })
                      );
                    },
                    child: const Text("LOG IN",style: TextStyle(
                        fontSize: 30,
                        color: Colors.white),),
                  )
              ),
              const SizedBox(height: 30,),
              Container(
                  width: 300,
                  height: 60,
                  color: Colors.orange,
                  child: TextButton(
                    onPressed: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return const SignUpPage();
                        })
                      );
                    },
                    child: const Text("SIGN UP",style: TextStyle(
                        fontSize: 30,
                        color: Colors.white),),
                  )
              ),
            ],
          )
        ],
      ),
    );
  }
}