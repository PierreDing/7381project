import 'package:demo1/pages/tabs/services/auth_services.dart';
import 'package:demo1/pages/tabs/shared/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

// Register.
class Register extends StatefulWidget {

  final Function toggleView;
  // ignore: use_key_in_widget_constructors
  const Register({ required this.toggleView });

  @override
  // ignore: library_private_types_in_public_api
  _RegisterState createState() => _RegisterState();

}

class _RegisterState extends State<Register> {

  // ignore: unused_field
  final AuthServices _auth = AuthServices();
  final _formKey = GlobalKey<FormState>();
  bool loading = false;

  // Store input of email and password.
  String email = '';
  String password = '';
  String error = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.brown[100],

      appBar: AppBar(
        backgroundColor: Colors.brown[400],
        elevation: 0.0,
        title: const Text('Register to DECO7381 project'),
        actions: <Widget>[
          ElevatedButton.icon(

            icon: const Icon(Icons.person),
            label: const Text('Sign In'),
            onPressed: () {
              widget.toggleView();
            },
            
          )
        ],
      ),

      body: Container(

        padding: const EdgeInsets.symmetric(
          vertical: 0.0, 
          horizontal: 50.0
        ),

        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              
              // Email input box.
              const SizedBox(height: 10.0),
              TextFormField(
                validator: (val) => val!.isEmpty ? 'Enter an email' : null,
                onChanged: (val) {
                  setState(() => email = val);
                },
                decoration: textInputDecoration.copyWith(hintText: 'Email'),
              ),

              // Password input box.
              const SizedBox(height: 10.0),
              TextFormField(
                // Hide password with dot.
                obscureText: true,
                validator: (val) => val!.length < 6 ? 'Enter a password longer than 6 characters' : null,
                onChanged: (val) {
                  setState(() => password = val);
                },
                decoration: textInputDecoration.copyWith(hintText: 'Password'),
              ),

              const SizedBox(height: 10.0),
              ElevatedButton(
                // Custom style for this button.
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, 
                  backgroundColor: Colors.pink[400]
                ),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    // Display loading widget.
                    setState(() => loading = true);
                    // ignore: unused_local_variable
                    dynamic result = await _auth.registerEmailPassoword(email, password, "what?");
                    // Check if registeration is success.
                    if (result == null) {
                      setState(() {
                        error = 'please enter a valid email';
                        loading = false;
                      });
                    }
                  }
                },
                child: 
                  const Text('Register'),
              ),
              const SizedBox(height: 10.0,),
              Text(
                error,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 14.0
                ),
              ),

              const SizedBox(height: 10.0,),

              Container(
                child: loading? const SpinKitChasingDots(
                  color: Colors.black,
                  size: 15,) : null
              )
            ]
          )
        ),
      ),
    );
  }
}