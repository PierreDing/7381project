import 'package:demo1/pages/tabs/models/user_information.dart';
import 'package:flutter/material.dart';

class UserTile extends StatelessWidget {

  final UserInformation userInformation;

  // ignore: use_key_in_widget_constructors
  const UserTile({
    required this.userInformation
  });

  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: const EdgeInsets.only(
        top: 5.0
      ),
      child: Card(
        margin: const EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
        child: ListTile(
          leading: const CircleAvatar(
            radius: 25.0,
            backgroundColor: Colors.amber,
            backgroundImage: AssetImage("assets/test_icon.png"),
          ),
          title: Text(userInformation.username),
          subtitle: Text(userInformation.address),
        ),
      )
    );
    
  }
}