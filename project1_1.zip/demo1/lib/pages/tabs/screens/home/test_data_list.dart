import 'package:demo1/pages/tabs/models/user_information.dart';
import 'package:demo1/pages/tabs/screens/home/user_tile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// ignore: use_key_in_widget_constructors
class DataList extends StatefulWidget {

  @override
  // ignore: library_private_types_in_public_api
  _DataListState createState() => _DataListState();

}

class _DataListState extends State<DataList> {
  @override
  Widget build(BuildContext context) {

    final testDatas = Provider.of<List<UserInformation>?>(context);
    // ignore: avoid_print
    print("-------");
    // ignore: avoid_print
    print(context);
    if (testDatas != null) {
      // ignore: avoid_function_literals_in_foreach_calls
      testDatas.forEach((userInformation) {
        // ignore: avoid_print
        print(userInformation.username);
        // ignore: avoid_print
        print(userInformation.address);
        // ignore: avoid_print
        print(userInformation.phoneNumber);
      });
    }    
    // ignore: avoid_print
    print("-------");

    if (testDatas != null) {
      return ListView.builder(
        itemCount: testDatas.length,
        itemBuilder: (context, index) {
          return UserTile(userInformation: testDatas[index]);
        },
      );
    } else {
      return Container();
    }
    
  }
}