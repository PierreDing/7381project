import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:demo1/pages/tabs/screens/authenticate/authenticate.dart';
import 'package:demo1/pages/tabs/services/api_services.dart';
import 'package:demo1/pages/tabs/services/auth_services.dart';
import "package:flutter/material.dart";
import 'package:demo1/pages/tabs/services/file_service.dart';
import 'package:demo1/pages/tabs/services/user_database_services.dart';

// ignore: use_key_in_widget_constructors
class Home extends StatelessWidget {

  final AuthServices _auth = AuthServices();

  @override
  Widget build(BuildContext context) {

    User? user = _auth.getCurrentUserInfo();


    // ignore: avoid_init_to_null
    File? fileOne = null;
    // ignore: avoid_init_to_null
    File? fileTwo = null;
    // ignore: avoid_init_to_null
    File? fileThree = null;

    if (user != null) {
      
      UserDatabaseServices userDatabaseService = UserDatabaseServices(user.uid);
      FileServices fileServices = FileServices(uid: user.uid);
      ApiServices apiServices = ApiServices(uid: user.uid);
      String uid = user.uid;

      return Column(
        children: [

          const SizedBox(height: 30,),

          ElevatedButton(
            onPressed: () async {
              Future<DocumentSnapshot<Object?>> result = userDatabaseService.getUserData(uid);
              result.then((value) {
                // ignore: avoid_print
                print(value["address"]);
              });
            },
            child: const Text("Get User"),
          ),

          const SizedBox(height: 30,),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Log Out'),
            onPressed: (() async {
              await _auth.signOut();
            })
          ),

          const SizedBox(height: 30,),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Up Load'),
            onPressed: (() async {
              await fileServices.uploadFiles(await fileServices.getImageFiles(), "no", "wrong");
            })
          ),

          const SizedBox(height: 30,),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Down Load'),
            onPressed: (() async {
              await fileServices.downloadFiles();
            })
          ),

          const SizedBox(height: 30,),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Save'),
            onPressed: (() async {
              List files = [];
              files.add(fileOne);
              files.add(fileTwo);
              files.add(fileThree);
              // ignore: avoid_print
              print("-------");
              // ignore: avoid_print
              print(files);
              userDatabaseService.savePost(files);
            })
          ),

          const SizedBox(height: 5,),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('One'),
            onPressed: (() async {
              fileOne = await fileServices.getImageFiles();
            })
          ),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Two'),
            onPressed: (() async {
              fileTwo = await fileServices.getImageFiles();
            })
          ),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Three'),
            onPressed: (() async {
              fileThree = await fileServices.getImageFiles();
            })
          ),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Get'),
            onPressed: (() async {
              await userDatabaseService.getPost();
            })
          ),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('API'),
            onPressed: (() async {
              apiServices.imageIdentification();
            })
          ),

          TextButton.icon(
            icon: const Icon(Icons.person),
            label: const Text('Translate'),
            onPressed: (() async {
              apiServices.translate("土豆");
            })
          ),

        ],
      );      
    } else {
      return const Authenticate();
    }

    // ignore: no_leading_underscores_for_local_identifiers



    /*
    return StreamProvider<List<UserInformation>?>.value(
      value: DatabaseService().test,
      initialData: null,
      child: Scaffold(
        backgroundColor: Colors.brown[50],
        appBar: AppBar(
          title: const Text('Project Test App'),
          backgroundColor: Colors.brown[400],
          elevation: 0.0,
          actions: <Widget>[
            TextButton.icon(
              icon: const Icon(Icons.settings),
              label: const Text('settings'),
              onPressed: () => _showSettingsPanel(),
            ),
          ],
        ),
        body: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/test_background.jpg"),
              fit: BoxFit.cover,
            ),
          ),
          child: DataList()
        ),
      ),
    );
    */
  }
}