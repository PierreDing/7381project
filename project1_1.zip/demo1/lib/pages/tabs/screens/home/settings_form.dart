import 'package:demo1/pages/tabs/models/deco_user.dart';
import 'package:demo1/pages/tabs/services/user_database_services.dart';
import 'package:demo1/pages/tabs/shared/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';

// ignore: use_key_in_widget_constructors
class SettingsForm extends StatefulWidget {

  @override
  // ignore: library_private_types_in_public_api
  _SettingsFormState createState() => _SettingsFormState();
}

class _SettingsFormState extends State<SettingsForm> {

  final _formKey = GlobalKey<FormState>();
  final List<String> addresses = ['Brisbane', 'Sydney', 'Melbourne'];

  // Form values
  // ignore: unused_field, prefer_final_fields
  String _currentUsername = 'not set';
  // ignore: unused_field, prefer_final_fields
  String _currentAddress = 'not set';
  // ignore: unused_field, prefer_final_fields
  String _currentPhoneNumber = 'not set';
  // ignore: prefer_final_fields, unused_field
  String _error = '';

  @override
  Widget build(BuildContext context) {

    final user = Provider.of<DECOUser>(context);

    return StreamBuilder<DECOUser>(
      stream: UserDatabaseServices(user.uid).testUserData,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          DECOUser? userInformation = snapshot.data;
          return Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                const Text(
                  'Update your address settings.',
                  style: TextStyle(fontSize: 10.0),
                ),
                const SizedBox(
                  height: 5.0
                ),
                TextFormField(
                  initialValue: userInformation?.username,
                  decoration: textInputDecoration,
                  validator: (val) => val!.isEmpty ? 'Please enter a username.' : null,
                  onChanged: (val) => setState(() => _currentUsername = val),
                ),
                const SizedBox(
                  height: 5.0
                ),
                DropdownButtonFormField(
                  items: addresses.map((address) {
                    return DropdownMenuItem(
                      value: address,
                      child: Text('Address: $address')
                    );
                  }).toList(), 
                  onChanged: (val) => setState(() => _currentAddress = val.toString()), 
                ),
                TextFormField(
                  initialValue: userInformation?.phoneNumber.toString(),
                  decoration: textInputDecoration,
                  validator: (val) {
                    if (val == null) {
                      return "Please enter a valid phone number.";
                    } else if ((int.tryParse(val)) == null) {
                      return "Please enter a valid phone number.";
                    } else {
                      return null;
                    }
                  },
                  onChanged: (val) {
                    try {
                      setState(() => _currentPhoneNumber = val);
                    } catch(e) {
                      // ignore: avoid_print
                      print(e.toString());
                    }
                  },
                ),
                const SizedBox(
                  height: 5.0
                ),
                Text(
                  _error,
                ),
                const SizedBox(
                  height: 5.0
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                  ),
                  child: const Text(
                    'Update',
                    style: TextStyle(
                      color: Colors.black
                    ),
                  ),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      await UserDatabaseServices(user.uid).updateUserData(_currentUsername, _currentAddress, _currentPhoneNumber);
                      // ignore: use_build_context_synchronously
                      Navigator.pop(context);
                    }
                  },
                )
              ]
            ),
          );
        } else {
          return const SpinKitChasingDots(
            color: Colors.black,
            size: 15,
          );
        }
      }
    );
  }

}