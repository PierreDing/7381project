import 'package:flutter/material.dart';
import 'no_matches.dart';
import 'plant_details.dart';

class Camera001 extends StatelessWidget {
  const Camera001({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add_a_photo),
        onPressed: (){
          Navigator.of(context).push(
              MaterialPageRoute(builder: (BuildContext context) {
                return const PlantDetails();
              })
          );
        },
      ),
      body: Center(
        child: Container(
          height: 400,
          width: 400,
          color: Colors.blue,
        ),
      ),
    );
  }


}