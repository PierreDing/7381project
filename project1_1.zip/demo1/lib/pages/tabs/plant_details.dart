import 'package:flutter/material.dart';
import '../../main.dart';
import 'Journal_log.dart';

class PlantDetails extends StatelessWidget {
  const PlantDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            actions: [
              IconButton(
                  onPressed: (){
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context){
                          return const PlantDetails();
                        })
                    );
                  },
                  icon: const Icon(Icons.refresh)
              ),
              IconButton(
                  onPressed: (){
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context){
                          return const MyApp();
                        })
                    );
                  },
                  icon: const Icon(Icons.home)
              )
            ]
        ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 20,),
            Container(
              width: 300,
              height: 300,
              color: Colors.blue,
            ),
            const SizedBox(height: 50,),
            const Text("Match Found",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 30,
                color: Colors.orange,
              ),
            ),
            const SizedBox(height: 20,),
            const Text("This is a plant.",
              style: TextStyle(
                fontSize: 20
              ),
            ),
            const SizedBox(height: 20,),
            Container(
                alignment: Alignment.center,
                width: 300,
                height: 60,
                color: Colors.orange,
                child: TextButton(
                  onPressed: (){
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return const JournalLog();
                        })
                    );
                  },
                  child: const Text("Journal Log",style: TextStyle(
                      fontSize: 30,
                      color: Colors.white),),
                )
            ),
          ],
        ),
      )
    );
  }
}