import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:image_picker/image_picker.dart';

class FileServices {

  late String uid;
  final Reference ref = FirebaseStorage.instance.ref();

  FileServices({required this.uid}) {
    uid = uid;
  }

  // Upload test.
  uploadFiles(File file, String pid, String imageFileName) async {    
    /*
    Directory appDocDir = await getApplicationDocumentsDirectory();
    String filePath = '${appDocDir.path}/test.txt';
    File file = File(filePath);
    // ignore: avoid_print
    file.writeAsString("something!!!!!");

    await textRef.putFile(file);
    */
    final path = '/$uid/$pid/$imageFileName.jpg';
    var userRef = ref.child(path);

    // Upload images.
    userRef.putFile(file);
  }

  // Get image files.
  getImageFiles() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    final image = File(pickedFile!.path);
    return image;
  }

  getImageFilePath() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    return pickedFile;
  }

  uploadCachedFile(File file) async {
    final path = '$uid/postID/image.jpg';
    var userRef = ref.child(path);

    userRef.putFile(file);
  }
  
  // Download test.
  downloadFiles() async {

    final path = 'oLxn6zKWWObLsQXzMqxtq3YqVaz2/lQC5ZgbVHqml2xRH3Okf/image_1.jpg';
    var userRef = ref.child(path);

    final imageUrl = await userRef.getDownloadURL();
    
    // ignore: avoid_print
    print(userRef);
    // ignore: avoid_print
    print(imageUrl);

    await GallerySaver.saveImage(imageUrl);

    // ignore: avoid_print
    print("finalle done!!!");

  }

  // Display image test.
  displayImages() async {

    final storageRef = FirebaseStorage.instance.ref();

    final imageUrl = await storageRef.child("anotherTest.jpg").getDownloadURL();

    return(imageUrl);

  }

}