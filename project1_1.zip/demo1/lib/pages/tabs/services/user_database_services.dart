import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/pages/tabs/models/deco_user.dart';
import 'package:demo1/pages/tabs/models/user_information.dart';
import 'file_service.dart';

// Database services.
class UserDatabaseServices {

  String uid;
  late CollectionReference userInfoCollection;
  late DocumentReference userInfoDocument;
  
  UserDatabaseServices(this.uid) {
    userInfoCollection = FirebaseFirestore.instance.collection("user_info");
    userInfoDocument = FirebaseFirestore.instance.collection("user_info").doc(uid);
  }

  Future<DocumentSnapshot<Object?>> getUserData(String uid) async {
    final userData = await userInfoDocument.get();
    return userData;
  }

  Future updateUserData(String username, String address, String phoneNumber) async {
    await userInfoCollection.doc(uid).set({
      'username': username,
      'address': address,
      'phone_number': phoneNumber
    });
  }

  // Get user information list from snapshot.
  List<UserInformation> _userInformationFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return UserInformation(
        username: doc["username"] ?? 'not set', 
        address: doc["address"] ?? 'not set', 
        phoneNumber: doc["phone_number"] ?? -1,
      );
    }).toList();
  }

  // Get snapshots from google firebase collection.
  Stream<List<UserInformation>> get test {
    return userInfoCollection.snapshots().map(_userInformationFromSnapshot);
  }

  // Get snapshots of this user from google firebase collection.
  Stream<DECOUser> get testUserData {
    return userInfoCollection.doc(uid).snapshots().map(_decoUserInformationFromSnapshot);
  }

  // Generate DECO user information model from snapshot.
  // ignore: unused_element
  DECOUser _decoUserInformationFromSnapshot(DocumentSnapshot snapshot) {
    return DECOUser(
      uid: uid, 
      username: snapshot['username'], 
      address: snapshot['address'], 
      phoneNumber: snapshot['phone_number']
    );
  }

  savePost(List<dynamic> files) async {

    FirebaseFirestore db = FirebaseFirestore.instance;
    FileServices fileServices = FileServices(uid: uid);
    Random random = Random.secure();
    int fileNumber = 0;
    Map uploadFiles = {};
    Map imagePaths = {};
    Map tempImagePaths = {};

    for (var file in files) {
      if (file != null) {
        fileNumber += 1;
        tempImagePaths["image_$fileNumber"] = "path_$fileNumber";
        uploadFiles["image_$fileNumber"] = file;
      }
    }

    final post = <String, dynamic>{
      "user_id": uid,
      "date": DateTime.now(),
      "brief": "This is an amazing post",
      "loaction": [-27.494777070784 + random.nextDouble(), 153.01352262497 + random.nextDouble()],
      "image_paths": imagePaths,
      "feature_tag": ["green", "like a orange", "round"],
      "description": "This is the description/main content of this post, it is usually longer then the brief, may have several sections."
    };
    db.collection("post").add(post).then((value) async {
      String pid = value.id;
      for (var file in uploadFiles.entries) {
        String fileName = file.key;
        await fileServices.uploadFiles(file.value, pid, fileName);
        // ignore: avoid_print
        print("done");        
        imagePaths[file.key] = '$uid/$pid/$fileName.jpg';
      }
      await db.collection("post").doc(value.id).update({"image_paths": imagePaths});
      // ignore: avoid_print
      print("all done!");
    },);
  }

  getPost() {

    FirebaseFirestore db = FirebaseFirestore.instance;
    db.collection("post").get().then((value) async {
      final data = value.docs;
      // ignore: avoid_print
      print("-------");
      for (var doc in data) {
        // ignore: avoid_print
        print(doc.data()["image_paths"]);
      }
      // ignore: avoid_print
      print("-------");
    },);

  }

}