import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:demo1/pages/tabs/services/file_service.dart';

class ApiServices {

  late String uid;

  ApiServices({required this.uid}) {
    uid = uid;
  }

  void imageIdentification() async {

    // Set api parameters.
    FileServices fileServices = FileServices(uid: uid);
    var host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=yDM1Y6Hv0BGDYwfsm65RD7d7&client_secret=Klq1iEs4asGiSSjjSpOGM70IjkbQK0R8';
    XFile image = await fileServices.getImageFilePath();
    var imageBytes = await image.readAsBytes();
    var imageBase64 = base64Encode(imageBytes);

    try {
      await Dio().get(host).then((value) {
        // ignore: avoid_print
        print("get token done");
        String token = value.data["access_token"];
        var url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/plant?access_token=$token";
        var params = {"image": imageBase64};

        // Use Baidu api to identify provided image file.
        Dio().post(url, data: params, options: Options(contentType: 'application/x-www-form-urlencoded')).then((value) async {
          List results = value.data["result"];
          int resultsNum = results.length;
          if (resultsNum < 2) {
            // ignore: avoid_print
            print("Find $resultsNum possibile result");
          } else {
            // ignore: avoid_print
            print("Find $resultsNum possibile results");
          }          
          for (var result in results) {
            // ignore: avoid_print
            double score = result["score"];
            // ignore: avoid_print
            print(result);
            var name = await translate(result["name"]).then((value) {
              return value;
            },);
            // ignore: avoid_print
            print("Has $score confidence with $name.");
          }
        },);
      },);
    } catch (e) {
      // ignore: avoid_print
      print(e);
    }

  }

  Future<String> translate(String text) async {

    // Set api parameters.
    String baseUrl = "http://api.fanyi.baidu.com/api/trans/vip/fieldtranslate?";
    Random random = Random.secure();
    int salt = random.nextInt(100000000);
    String sign = md5.convert(utf8.encode("20221011001385514$text${salt}medicineV2M4a7NtuLCAhvhaRsIE")).toString();

    // Get final api url.
    var url = "${baseUrl}q=$text&from=zh&to=en&appid=20221011001385514&salt=$salt&domain=medicine&sign=$sign";

    // Transalte Chinese string to English string.
    String result = await Dio().get(url).then((value) {
      return (value.data["trans_result"][0]["dst"]);
    },);

    return result;

  }

}